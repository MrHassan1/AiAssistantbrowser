// content.js - Injected into the active tab

// Function to "scan" the page and return relevant information
function scanPage() {
    // This is a simplified example. A real agent would extract
    // more detailed information (e.g., element visibility, position, role).
    const actionableElements = Array.from(document.querySelectorAll('a, button, input, select, textarea'))
        .filter(el => {
            // Basic visibility check
            const rect = el.getBoundingClientRect();
            const styles = window.getComputedStyle(el);
            return rect.width > 0 && rect.height > 0 &&
                styles.visibility !== 'hidden' && styles.display !== 'none';
        })
        .map((el, index) => {
            return {
                tag: el.tagName,
                text: (el.innerText || el.value || '').trim().substring(0, 100), // Truncate text
                id: el.id,
                name: el.name,
                // class: el.className, // Class names often add noise
                href: el.href,
                placeholder: el.placeholder,
                ariaLabel: el.ariaLabel,
                // We'll use a data-gemini-id for easier targeting
                geminiId: `g-${index}`
            };
        });
    // Inject geminiId for easier targeting from background script
    actionableElements.forEach((el, index) => {
        const originalElement = Array.from(document.querySelectorAll('a, button, input, select, textarea'))[index];
        originalElement.setAttribute('data-gemini-id', `g-${index}`);
    });

    const pageTitle = document.title;
    const pageUrl = window.location.href;
    const pageContent = document.body.innerText.substring(0, 2000); // Send first 2000 chars for brevity

    return {
        title: pageTitle,
        url: pageUrl,
        content_summary: pageContent,
        actionable_elements: actionableElements
    };
}

// Function to "click" an element
function clickElement(geminiId) {
    const element = document.querySelector(`[data-gemini-id="${geminiId}"]`);
    if (element) {
        element.click();
        return { success: true, message: `Clicked element with geminiId: ${geminiId}` };
    } else {
        return { success: false, message: `Element with geminiId ${geminiId} not found.` };
    }
}

// Function to "type" text into an input field
function typeIntoElement(geminiId, text) {
    const element = document.querySelector(`[data-gemini-id="${geminiId}"]`);
    if (element && (element.tagName === 'INPUT' || element.tagName === 'TEXTAREA')) {
        element.value = text;
        // Dispatch input event to ensure changes are registered by frameworks like React
        element.dispatchEvent(new Event('input', { bubbles: true }));
        element.dispatchEvent(new Event('change', { bubbles: true }));
        return { success: true, message: `Typed "${text}" into element with geminiId: ${geminiId}` };
    } else {
        return { success: false, message: `Element with geminiId ${geminiId} not found or not an input/textarea.` };
    }
}

// Listen for messages from the background script
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.action === 'scanPage') {
        const pageInfo = scanPage();
        sendResponse({ type: 'pageInfo', data: pageInfo });
    } else if (message.action === 'clickElement') {
        const result = clickElement(message.geminiId);
        sendResponse({ type: 'actionResult', data: result });
    } else if (message.action === 'typeIntoElement') {
        const result = typeIntoElement(message.geminiId, message.text);
        sendResponse({ type: 'actionResult', data: result });
    } else if (message.action === 'navigateTo') {
        window.location.href = message.url;
        sendResponse({ type: 'actionResult', data: { success: true, message: `Navigating to ${message.url}` } });
    }
    // Return true to indicate that sendResponse will be called asynchronously
    return true;
});

// Initial scan when script is injected
// This can be useful for the agent to get initial context
// However, it's better to let background script explicitly ask for it
// const initialPageInfo = scanPage();
// chrome.runtime.sendMessage({ type: 'initialPageInfo', data: initialPageInfo });