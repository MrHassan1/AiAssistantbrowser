document.addEventListener('DOMContentLoaded', function () {
    const taskInput = document.getElementById('task-input');
    const runButton = document.getElementById('run-button');
    const chatHistory = document.getElementById('chat-history');

    let updateInterval;
    let lastKnownResult = '';
    let isTaskRunning = false;

    function addMessage(sender, text) {
        if (!text) return;
        const msgDiv = document.createElement('div');
        msgDiv.classList.add('message', sender);
        msgDiv.textContent = text;
        chatHistory.appendChild(msgDiv);
        chatHistory.scrollTop = chatHistory.scrollHeight;
    }

    async function updateTaskStatus() {
        try {
            const response = await chrome.runtime.sendMessage({ action: 'getTaskStatus' });
            if (response) {
                // If the result has changed and is meaningful, display it
                // We avoid displaying "Ready to receive a task" repeatedly or as an agent response usually
                if (response.result !== lastKnownResult) {
                    // Filter out the initial idle message if we are running
                    if (isTaskRunning || response.status !== 'idle') {
                        // Only show meaningful updates, avoiding duplicate status messages if possible
                        // But simple approach: showing everything from backend is safer for now
                        addMessage('agent', response.result);
                    }
                    lastKnownResult = response.result;
                }

                if (response.status === 'completed' || response.status === 'error' || response.status === 'idle') {
                    if (isTaskRunning) {
                        isTaskRunning = false;
                        runButton.disabled = false;
                        clearInterval(updateInterval);
                    }
                } else {
                    isTaskRunning = true;
                    runButton.disabled = true;
                }
            }
        } catch (e) {
            console.error("Error polling status:", e);
        }
    }

    // Initial check (don't add message, just sync state)
    chrome.runtime.sendMessage({ action: 'getTaskStatus' }, (response) => {
        if (response) {
            lastKnownResult = response.result; // Sync initial state so we don't duplicate it
            if (response.status === 'in_progress') {
                isTaskRunning = true;
                runButton.disabled = true;
                updateInterval = setInterval(updateTaskStatus, 1000);
            }
        }
    });

    function sendTask() {
        const task = taskInput.value.trim();
        if (!task) return;

        addMessage('user', task);
        taskInput.value = '';

        isTaskRunning = true;
        runButton.disabled = true;
        lastKnownResult = 'Starting task...'; // Reset/Set initial expected state
        addMessage('agent', 'Starting task...');

        // Send to background
        chrome.runtime.sendMessage({ action: 'startTask', task: task }, (response) => {
            if (chrome.runtime.lastError) {
                console.error("BG Error:", chrome.runtime.lastError);
                addMessage('system', 'Extension Error: ' + chrome.runtime.lastError.message + '. Please reload the extension.');
                isTaskRunning = false;
                runButton.disabled = false;
                clearInterval(updateInterval);
            }
        });

        // Start polling
        if (updateInterval) clearInterval(updateInterval);
        updateInterval = setInterval(updateTaskStatus, 1000);
    }

    runButton.addEventListener('click', sendTask);

    taskInput.addEventListener('keypress', function (e) {
        if (e.key === 'Enter' && !e.shiftKey) {
            e.preventDefault();
            sendTask();
        }
    });
});
