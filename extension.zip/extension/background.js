// background.js - Service worker for the extension

let currentTaskState = { status: 'idle', result: 'Ready to receive a task.' };

// Function to send a message to the content script in the active tab,
// ensuring the content script is injected first.
async function ensureAndSendMessageToContentScript(tabId, action, payload = {}) {
    // Try sending first (optimistic)
    try {
        const response = await chrome.tabs.sendMessage(tabId, { action, ...payload });
        return response;
    } catch (e) {
        // If it failed because the script isn't there, inject it and try again
        const isConnectionError = e.message.includes("Receiving end does not exist") ||
            e.message.includes("The message port closed before a response was received");

        if (isConnectionError) {
            console.log("Content script missing. Injecting now...");
            try {
                await chrome.scripting.executeScript({
                    target: { tabId: tabId },
                    files: ['content.js'],
                });
                // Short wait to ensure initialization
                await new Promise(r => setTimeout(r, 100));

                // Retry sending
                const response = await chrome.tabs.sendMessage(tabId, { action, ...payload });
                return response;
            } catch (injectError) {
                console.error("Injection failed:", injectError);
                if (injectError.message.includes("Cannot access a chrome:// URL")) {
                    return { error: "Cannot run on this page (chrome:// URL). Please use a normal website." };
                }
                return { error: "Failed to inject agent into page: " + injectError.message };
            }
        } else {
            // Other error
            return { error: e.message };
        }
    }
}

// Function to communicate with the Python backend
async function sendToPythonBackend(endpoint, data) {
    try {
        const response = await fetch(`http://localhost:5000/${endpoint}`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(data)
        });
        if (!response.ok) {
            const errorText = await response.text();
            throw new Error(`HTTP error! status: ${response.status}, message: ${errorText}`);
        }
        return await response.json();
    } catch (error) {
        console.error("Error communicating with Python backend:", error);
        return { error: "Error communicating with backend: " + error.message };
    }
}

// Main listener for messages from the popup script
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.action === 'startTask') {
        // Acknowledge task start immediately
        currentTaskState = { status: 'in_progress', result: 'Starting task...' };
        sendResponse(currentTaskState); // Respond immediately to the popup

        // Now, asynchronously run the task
        executeTask(message.task);
        return true;
    } else if (message.action === 'getTaskStatus') {
        sendResponse(currentTaskState); // Respond with the current task state
    }
    return false;
});

// Function to execute the task steps
async function executeTask(task) {
    try {
        const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
        if (!tab) {
            throw new Error("No active tab found.");
        }

        for (let step = 0; step < 10; step++) { // Limit to 10 steps
            // Provide feedback to UI that we are scanning
            currentTaskState = { status: 'in_progress', result: `Step ${step + 1}: Scanning page...` };
            // Note: We don't explicitly sendResponse here because `getTaskStatus` polling will pick it up.

            const pageInfoResponse = await ensureAndSendMessageToContentScript(tab.id, 'scanPage');
            if (pageInfoResponse.error) {
                currentTaskState = { status: 'error', result: pageInfoResponse.error };
                break;
            }

            // Provide feedback that we are thinking
            currentTaskState = { status: 'in_progress', result: `Step ${step + 1}: Thinking...` };

            const aiDecisionResponse = await sendToPythonBackend('decide-action', {
                task: task,
                page_info: pageInfoResponse.data
            });

            if (aiDecisionResponse.error) {
                currentTaskState = { status: 'error', result: aiDecisionResponse.error };
                break;
            }

            const aiAction = aiDecisionResponse.action;
            const aiResult = aiDecisionResponse.result;

            currentTaskState = { status: 'in_progress', result: aiResult || `Executing action: ${aiAction.type}` };

            if (aiAction.type === 'done') {
                currentTaskState = { status: 'completed', result: aiResult || "Task completed." };
                break;
            } else if (aiAction.type === 'error') {
                currentTaskState = { status: 'error', result: aiResult || "An error occurred in the AI backend." };
                break;
            } else if (aiAction.type === 'click') {
                await ensureAndSendMessageToContentScript(tab.id, 'clickElement', { geminiId: aiAction.target_gemini_id });
                await new Promise(resolve => setTimeout(resolve, 1000));
            } else if (aiAction.type === 'type') {
                await ensureAndSendMessageToContentScript(tab.id, 'typeIntoElement', { geminiId: aiAction.target_gemini_id, text: aiAction.text });
            } else if (aiAction.type === 'navigate') {
                await ensureAndSendMessageToContentScript(tab.id, 'navigateTo', { url: aiAction.url });
                await new Promise(resolve => setTimeout(resolve, 2000));
            } else {
                currentTaskState = { status: 'error', result: `Unknown AI action type: ${aiAction.type}` };
                break;
            }
        }
    } catch (error) {
        console.error("Background script error:", error);
        currentTaskState = { status: 'error', result: "An unexpected error occurred: " + error.message };
    } finally {
        if (currentTaskState.status === 'in_progress') {
            currentTaskState = { status: 'error', result: currentTaskState.result + " (Task may have exceeded step limit.)" };
        }
    }
}

// Open the side panel when the extension icon is clicked
if (chrome.sidePanel && chrome.sidePanel.setPanelBehavior) {
    chrome.sidePanel
        .setPanelBehavior({ openPanelOnActionClick: true })
        .catch((error) => console.error(error));
}